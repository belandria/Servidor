@extends('layouts.app')

@if(Auth::check())

@section('content')
    <div class="container card-2" style="text-align: center">
        <div class="raw">
            <div class="col-sm-12"><a href="/" class="btn btn-primary waves-effect waves-light" style="width: 100%; margin-top:20px;  margin-bottom:20px;"><i class="fa fa-home"></i> Ir al inicio</a><br></div>
        </div>
        <div class="raw">
            <div class="col-sm-4"><b>#</b></div>
            <div class="col-sm-4"><b># de usuario</b></div>
            <div class="col-sm-4"><b>Fecha de registro</b></div>
        </div>
        <br>
        @foreach($requests as $request)

                <div class="raw">
                    <div class="col-sm-4">
                        {{ $request->id }}
                    </div>
                    <div class="col-sm-4">
                        @foreach($appUsers as $appUser)
                            <div class="prueba"
                                 @if ($appUser->user_enabled == 0 ) 
                                    style="background-color: #e74c3c; color: white" title="Usuario inhabilitado" 
                                @endif 
                            >
                            @if ($request->appUser_id == $appUser->id )
                                <a href="/findAppUserById/{{ $request->appUser_id }}"
                                @if ($appUser->user_enabled == 0 ) 
                                    style="color: white" inhabilitado" 
                                @endif
                                    >{{$fullName = $appUser->firstname . ' ' . $appUser->lastname }}
                                </a>
                            @endif
                            </div>
                        @endforeach
                    </div>
                    <div class="col-sm-4">
                        {{ $request->created_at }}
                    </div>
                    <hr>
                </div>
        @endforeach
    </div>
@endsection
@endif

@if(Auth::guest())
    <div class="container card-2" style="text-align: center">
        <div class="raw">
            <div class="col-sm-12"><a href="/" class="btn btn-primary waves-effect waves-light" style="width: 100%; margin-top:20px;  margin-bottom:20px;"><i class="fa fa-home"></i></a><br></div>
        </div>
    </div>
@endif