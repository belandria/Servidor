    @extends('layouts.app')

    @section('content')
    <div class="container card-2">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading card-title">Panel de administración</div>
                    <hr>
                    <a href="/requests" class="btn btn-primary waves-effect waves-light" style="width: 100%">Ver lista de registros</a>
                    <hr>
                    <div class="panel-body">
                        <h1 style="text-align: center;">Registrar nuevo usuario</h1>
                        @include('newAppUserForm')
                        <hr>
                        <h1 style="text-align: center;">Buscar usuario registrado</h1>
                        @include('findAppUserForm')
                    </div>
                </div>
            </div>
        </div>
    </div>
    @endsection
