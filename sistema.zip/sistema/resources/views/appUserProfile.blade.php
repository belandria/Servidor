<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Trabajo Especial De Grado</title>

    <!-- Fonts -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css" rel='stylesheet' type='text/css'>
    <link href="https://fonts.googleapis.com/css?family=Lato:200,300,400,700" rel='stylesheet' type='text/css'>

    <!-- Styles -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.5/css/materialize.min.css">
    <link href="css/style.css" rel="stylesheet">
    {{-- <link href="{{ elixir('css/app.css') }}" rel="stylesheet"> --}}

    <style>

html, body {
    height: 100%;
}
body {
    margin: 0;
    padding: 0;
    width: 100%;
    display: table;
    font-weight: 200;
    font-family: 'Lato';
    background-color: #eaeaea;
}

p, h1, h2 {
    font-weight: 200;
    font-family: 'Lato';
}

h3 {
    font-weight: 100;
    font-family: 'Lato';
    font-size: 24px;
    max-width: 600px;
    text-align: center;
}

.container-centered {
    text-align: center;
    display: table-cell;
    vertical-align: middle;
}
.content {
    text-align: center;
    display: inline-block;
}
.title {
    font-size: 96px;
    font-family: 'Lato';
    font-weight: 200;
}


.card {
    background: #fff;
    border-radius: 0px;
    padding: 30px;
}

.card-1 {
    background: #fff;
    box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
    transition: all 0.2s ease-in-out;
}

.card-1:hover {
    box-shadow: 0 10px 20px rgba(0,0,0,0.19), 0 6px 6px rgba(0,0,0,0.23);
}

.card-2 {
    background: #fff;
    box-shadow: 0 3px 6px rgba(0,0,0,0.16), 0 3px 6px rgba(0,0,0,0.23);
    border-radius: 0px;
    padding: 30px;
}

.card-3 {
    background: #fff;
    box-shadow: 0 10px 20px rgba(0,0,0,0.19), 0 6px 6px rgba(0,0,0,0.23);
}

.card-4 {
    box-shadow: 0 14px 28px rgba(0,0,0,0.25), 0 10px 10px rgba(0,0,0,0.22);
}

.card-5 {
    box-shadow: 0 19px 38px rgba(0,0,0,0.30), 0 15px 12px rgba(0,0,0,0.22);
}

    </style>
</head>
<body id="app-layout">

	    <div class="container container-centered" style="text-align: center">
	    	<?php if($appUser->user_enabled==0) { ?>
		    	<div class="row" style="background-color: #e74c3c; padding: 20px; color: white">
		    		<p style="color: white">Usuario inhabilitado</p>
		    	</div>
	    	<?php } ?>
	        <div class="row card card-2">
	            <div class="col-sm-4" style="padding: 30px;">
	                <p>Nombre: <b>{{ $appUser->firstname }} {{ $appUser->lastname }}</b></p>
	            </div>
	            <div class="col-sm-4" style="padding: 30px;">
	                <p>Cédula de identidad: <b>{{ $appUser->ci }}</b></p>
	            </div>
	            <div class="col-sm-4" style="padding: 30px;">
	                <p>Correo Electrónico: <b>{{ $appUser->email }}</b></p>
	            </div>
	            <div class="col-sm-4" style="padding: 30px;">
	                <p>Fecha de registro: <b>{{ $appUser->created_at }}</b></p>
	            </div>
	            <div class="col-sm-4" style="padding: 30px;">
	                <p>Registrado por: <b>{{ $appUser->registered_by }}</b></p>
	            </div>
	            <div class="col-sm-4" style="padding: 30px;">
	            	<?php if($appUser->user_enabled==1) { ?>
	                	<p><a href="/block/{{ $appUser->id }}" title="Inhabilitar usuario" style="color: #e74c3c"><i class="fa fa-ban fa-2x"></i></a></p>

	            	<?php } if($appUser->user_enabled==0) { ?>
	                	<p><a href="/unblock/{{ $appUser->id }}" title="Habilitar usuario" style="color: #2ecc71"><i class="fa fa-check fa-2x"></i></a></p>
	                <?php } ?>
	            </div>
	        </div>
	        <br>
	        <a href="/requests" class="btn btn-primary waves-effect waves-light">Regresar</a>
    </div>
    
    <!-- JavaScripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.5/js/materialize.min.js"></script>
    {{-- <script src="{{ elixir('js/app.js') }}"></script> --}}
</body>
</html>

