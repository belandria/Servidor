@extends('layouts.app')

@section('content')
    <div class="container-centered">
        <div class="content">
            <div class="title">Usuario no registrado</div>
            <br>
            <a href="{{ URL::previous() }}" class="btn btn-primary">Regresar</a>
        </div>
    </div>
@endsection
