<?php $__env->startSection('content'); ?>
    <div class="container container-centered" style="text-align: center">
        <div class="row card card-2">
            <div class="col-sm-4" style="padding: 30px;">
                <p>Nombre: <b><?php echo e($appUser->firstname); ?> <?php echo e($appUser->lastname); ?></b></p>
            </div>
            <div class="col-sm-4" style="padding: 30px;">
                <p>Cédula de identidad: <b><?php echo e($appUser->ci); ?></b></p>
            </div>
            <div class="col-sm-4" style="padding: 30px;">
                <p>Correo Electrónico: <b><?php echo e($appUser->email); ?></b></p>
            </div>
            <div class="col-sm-6" style="padding: 30px;">
                <p>Fecha de registro: <b><?php echo e($appUser->created_at); ?></b></p>
            </div>
            <div class="col-sm-6" style="padding: 30px;">
                <p>Registrado por: <b><?php echo e($appUser->registered_by); ?></b></p>
            </div>
        </div>
        <br>
        <a href="<?php echo e(URL::previous()); ?>" class="btn btn-primary">Regresar</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>