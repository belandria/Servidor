    

    <?php $__env->startSection('content'); ?>
    <div class="container card-2">
        <div class="row">
            <div class="col-md-10 col-md-offset-1">
                <div class="panel panel-default">
                    <div class="panel-heading card-title">Panel de administración</div>
                    <hr>
                    <a href="/requests" class="btn btn-primary waves-effect waves-light" style="width: 100%">Ver lista de registros</a>
                    <hr>
                    <div class="panel-body">
                        <h1 style="text-align: center;">Registrar nuevo usuario</h1>
                        <?php echo $__env->make('newAppUserForm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <hr>
                        <h1 style="text-align: center;">Buscar usuario registrado</h1>
                        <?php echo $__env->make('findAppUserForm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>