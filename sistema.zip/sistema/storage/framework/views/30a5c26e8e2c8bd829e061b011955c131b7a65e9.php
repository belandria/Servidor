

<?php if(Auth::check()): ?>

<?php $__env->startSection('content'); ?>
    <div class="container card-2" style="text-align: center">
        <div class="raw">
            <div class="col-sm-12"><a href="/" class="btn btn-primary waves-effect waves-light" style="width: 100%; margin-top:20px;  margin-bottom:20px;"><i class="fa fa-home"></i> Ir al inicio</a><br></div>
        </div>
        <div class="raw">
            <div class="col-sm-4"><b>#</b></div>
            <div class="col-sm-4"><b># de usuario</b></div>
            <div class="col-sm-4"><b>Fecha de registro</b></div>
        </div>
        <br>
        <?php foreach($requests as $request): ?>

                <div class="raw">
                    <div class="col-sm-4">
                        <?php echo e($request->id); ?>

                    </div>
                    <div class="col-sm-4">
                        <?php foreach($appUsers as $appUser): ?>
                            <div class="prueba"
                                 <?php if($appUser->user_enabled == 0 ): ?> 
                                    style="background-color: #e74c3c; color: white" title="Usuario inhabilitado" 
                                <?php endif; ?> 
                            >
                            <?php if($request->appUser_id == $appUser->id ): ?>
                                <a href="/findAppUserById/<?php echo e($request->appUser_id); ?>"
                                <?php if($appUser->user_enabled == 0 ): ?> 
                                    style="color: white" inhabilitado" 
                                <?php endif; ?>
                                    ><?php echo e($fullName = $appUser->firstname . ' ' . $appUser->lastname); ?>

                                </a>
                            <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="col-sm-4">
                        <?php echo e($request->created_at); ?>

                    </div>
                    <hr>
                </div>
        <?php endforeach; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php if(Auth::guest()): ?>
    <div class="container card-2" style="text-align: center">
        <div class="raw">
            <div class="col-sm-12"><a href="/" class="btn btn-primary waves-effect waves-light" style="width: 100%; margin-top:20px;  margin-bottom:20px;"><i class="fa fa-home"></i></a><br></div>
        </div>
    </div>
<?php endif; ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>