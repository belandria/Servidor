<form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/findAppUser')); ?>">
    <?php echo csrf_field(); ?>


    <div class="row">
            <div class="input-field col s6 <?php echo e($errors->has('ci') ? ' has-error' : ''); ?>">
                <input id="ci" type="text" class="validate" name="ci" value="<?php echo e(old('ci')); ?>">
                <label for="ci">Cédula de identidad</label>
            </div>
            <div class="input-field col s6">
                <button type="submit" class="btn btn-primary waves-effect waves-light">
                    <i class="fa fa-btn fa-search"></i> Buscar usuario registrado
                </button>
            </div>
     </div>
</form>