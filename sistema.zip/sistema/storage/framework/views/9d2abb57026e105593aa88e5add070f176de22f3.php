<?php $__env->startSection('content'); ?>


<div class="container-centered">
    <div class="row">
        <div class="content">
            <h1>Trabajo Especial</h1>
            <h3>Control de acceso inalámbrico usando dispositivos móviles con plataforma Android para Muebles La Canastilla, C.A.</h3>
        </div>
    </div>
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Inicio de sesión</div>
                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/login')); ?>">
                        <?php echo csrf_field(); ?>


                        <div class="row">
                            <div class="input-field col s6 <?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                <input id="name" type="text" class="validate" name="name" value="<?php echo e(old('name')); ?>">
                                <label for="name">Usuario</label>
                                <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <div class="input-field col s6 <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                <input id="password" type="password" class="validate" name="password">
                                <label for="password">Contraseña</label>
                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="input-field col s6">
                                <p style="text-align: center">
                                    <input type="checkbox" id="checkbox"  name="remember"/>
                                    <label for="checkbox"> Mantener sesión activa</label>
                                </p>
                            </div>
                            <div class="input-field col s6">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-btn fa-sign-in"></i>Iniciar sesión
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>