<form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/createAppUser')); ?>">
    <?php echo csrf_field(); ?>


    <div class="row">
        <div class="input-field col s6 <?php echo e($errors->has('firstname') ? ' has-error' : ''); ?>">
            <input id="firstname" type="text" class="validate" name="firstname" value="<?php echo e(old('firstname')); ?>">
            <label for="firstname">nombre</label>
        </div>
        <div class="input-field col s6 <?php echo e($errors->has('lastname') ? ' has-error' : ''); ?>">
            <input id="lastname" type="text" class="validate" name="lastname" value="<?php echo e(old('lastname')); ?>">
            <label for="lastname">Apellido</label>
        </div>
    </div>


    <div class="row">
        <div class="input-field col s6 <?php echo e($errors->has('ci') ? ' has-error' : ''); ?>">
            <input id="ci" type="text" class="validate" name="ci" value="<?php echo e(old('ci')); ?>">
            <label for="ci">Cédula de identidad</label>
        </div>
        <div class="input-field col s6 <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
            <input id="email" type="email" class="validate" name="email" value="<?php echo e(old('email')); ?>">
            <label for="email">Correo electrónico</label>
        </div>
    </div>

            <button type="submit" class="btn btn-primary waves-effect waves-light" style="width: 100%">
                <i class="fa fa-btn fa-user"></i> Registrar nuevo usuario
            </button>

    <input type="hidden" name="registered_by" value="<?php echo e(Auth::user()->name); ?>">
</form>