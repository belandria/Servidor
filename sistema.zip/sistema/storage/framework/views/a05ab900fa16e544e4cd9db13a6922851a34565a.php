<?php $__env->startSection('content'); ?>
    <div class="container card-2" style="text-align: center">
        <div class="raw">
            <div class="col-sm-12"><a href="/" class="btn btn-primary waves-effect waves-light" style="width: 100%; margin-top:20px;  margin-bottom:20px;"><i class="fa fa-home"></i> Ir al inicio</a><br></div>
        </div>
        <div class="raw">
            <div class="col-sm-4"><b>#</b></div>
            <div class="col-sm-4"><b># de usuario</b></div>
            <div class="col-sm-4"><b>Fecha de registro</b></div>
        </div>
        <br>
        <?php foreach($requests as $request): ?>
                <div class="raw">
                    <div class="col-sm-4">
                        <?php echo e($request->id); ?>

                    </div>
                    <div class="col-sm-4">
                        <?php echo e($request->appUser_id); ?> - <a href="findAppUserById/<?php echo e($request->appUser_id); ?>">Ver perfil</a>
                    </div>
                    <div class="col-sm-4">
                        <?php echo e($request->created_at); ?>

                    </div>
                    <hr>
                </div>
        <?php endforeach; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>