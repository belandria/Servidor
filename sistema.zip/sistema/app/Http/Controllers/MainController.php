<?php

namespace App\Http\Controllers;

use App\AppUser;
use Illuminate\Http\Request;
use DB;
use App\Http\Requests;

class MainController extends Controller
{
    public function CreateAppUser(Request $request)
    {
        $appUser = new AppUser();

        $this->validate($request, [
            'firstname' => 'required',
            'lastname' => 'required',
            'email' => 'required|Email',
            'ci' => 'required',
            'registered_by' => 'required'
        ]);

        $appUser->firstname = $request->firstname;
        $appUser->lastname = $request->lastname;
        $appUser->email = $request->email;
        $appUser->registered_by = $request->registered_by;
        $appUser->ci = $request->ci;

        $appUser->save();

        return redirect('/home');
    }
    
    public function findAppUser(Request $request)
    {
        $ci = $request->ci;
        $appUser = AppUser::where('ci', $ci)->first();

        if ($appUser == NULL){
            return View('errors.appUserNotFound');
        } else {
            return View('appUserProfile')->with('appUser', $appUser);
        }
    }

    public function findAppUserById($appUserId)
    {
        $appUser = AppUser::where('id', $appUserId)->first();
        return View('appUserProfile')->with('appUser', $appUser);
    }

    public function blockAppUser($appUserId)
    {
        $appUser = AppUser::where('id', $appUserId)->first();
        $appUser->user_enabled=0;
        $appUser->save();

        return View('appUserProfile')->with('appUser', $appUser);
    }

        public function unblockAppUser($appUserId)
    {
        $appUser = AppUser::where('id', $appUserId)->first();
        $appUser->user_enabled=1;
        $appUser->save();

        return View('appUserProfile')->with('appUser', $appUser);
    }

    public function getRequests(){
        $requests = DB::table('requests') ->orderBy('id', 'desc')->get();
        $appUsers = DB::table('app_users')->get();
        return View('requestsList')->with('requests', $requests)->with('appUsers', $appUsers);
   }

   public function registerRequest(Request $request)
   {
        $appUser_id = $request->appUser_id;
        DB::table('requests')->insert(['appUser_id' => $appUser_id]);
   }

}
