<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppUser extends Model
{

    protected $fillable = [
        'firstname', 'lastname', 'email', 'ci', 'user_enabled'
    ];
}
